Cara Menjalakan Script
1. Download dulu python 
2. Download dulu https://visualstudio.microsoft.com/visual-cpp-build-tools/ 
3. install module pythonnya 
- pip install requests
- pip install web3
- pip install bip-utils
- pip install tqdm
4. jalankan toolsnya

Penjelasan Menu Tools
[1] Generate Mnemonic+PrivKey+Address = buat generate 
[2] Make PrivKey+Wallet Form  Mnemonic = yang ini kalo anda punya list mnemonic mau buat di ubah jadi privkey+address untuk check balance
[3] Check Balance USDT|BUSD|BNB = yah jelas buat check balance, yang di cek disini USDT|BUSD|BNB tambah sendiri modify kode checkbalance.py


Semoga JP 0.0000001% :V